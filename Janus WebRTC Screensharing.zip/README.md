This is a slightly modified version of Henrik Joreteg's
[Chrome extension](https://github.com/henrikjoreteg/getscreenmedia) for
WebRTC screensharing, in order to better suit it to the requirements for
[Janus](https://github.com/meetecho/janus-gateway).
